#!/bin/bash

# กำหนดโฟลเดอร์เป้าหมาย
LOG_DIR="./logs"

# กำหนด Keyword ที่ต้องการค้นหา
# คุณสามารถเปลี่ยนค่า 'foo' ตรงนี้ได้ตามต้องการ
SEARCH_KEYWORD="foo" 

# ตรวจสอบว่าโฟลเดอร์ /logs มีอยู่จริงหรือไม่
if [ ! -d "$LOG_DIR" ]; then
    echo "Error: Directory $LOG_DIR not found."
    exit 1
fi

echo "Searching for '$SEARCH_KEYWORD' in all files within $LOG_DIR..."

# วนลูปผ่านไฟล์ทั้งหมดในโฟลเดอร์ /logs
for file in "$LOG_DIR"/*; do
    if [ -f "$file" ]; then # ตรวจสอบว่าเป็นไฟล์จริงหรือไม่
        FILENAME=$(basename "$file")
        OUTPUT_FILE="${file}.access"
        
        echo "Processing $FILENAME..."
        
        # ใช้ grep เพื่อค้นหา Keyword และบันทึกผลลัพธ์ลงในไฟล์ .access
        grep "$SEARCH_KEYWORD" "$file" > "$OUTPUT_FILE"
        
        if [ $? -eq 0 ]; then
            echo "Results saved to $OUTPUT_FILE"
        else
            echo "No lines containing '$SEARCH_KEYWORD' found in $FILENAME or an error occurred. An empty or incomplete file might be created: $OUTPUT_FILE"
        fi
    fi
done

echo "Script finished."