package com.example.demo.member;

import java.util.ArrayList;
import java.util.List;

public class MemberRiskModel {
    private int rowNum;
    private String employeeNo;
    private String level;

    private List<ErrorModel> errors;

    public MemberRiskModel(int rowNum, String employeeNo, String level) {
        this.rowNum = rowNum;
        this.employeeNo = employeeNo;
        this.level = level;
        this.errors = new ArrayList<>();
    }

    public int getRowNum() {
        return rowNum;
    }

    public void setRowNum(int rowNum) {
        this.rowNum = rowNum;
    }

    public String getEmployeeNo() {
        return employeeNo;
    }

    public void setEmployeeNo(String employeeNo) {
        this.employeeNo = employeeNo;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public List<ErrorModel> getErrors() {
        return errors;
    }

    public void setErrors(List<ErrorModel> errors) {
        this.errors = errors;
    }

    @Override
    public String toString() {
        return "MemberImportRow{" +
                "rowNum=" + rowNum +
                ", employeeNo='" + employeeNo + '\'' +
                ", level='" + level + '\'' +
                ", errors=" + errors +
                '}';
    }
}
