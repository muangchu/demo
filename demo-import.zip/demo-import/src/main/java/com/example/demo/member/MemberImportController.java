package com.example.demo.member;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MemberImportController {

    private final MemberImportService memberImportService;

    public MemberImportController(MemberImportService memberImportService) {
        this.memberImportService = memberImportService;
    }

    @GetMapping(path = "/members/import")
    public ResponseEntity<String> importMember(){
        memberImportService.importMember(null);
        return ResponseEntity.ok("import work!");
    }
}
