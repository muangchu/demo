package com.example.demo.member;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class MemberImportServiceImpl implements MemberImportService{
    private static final Logger logger = LoggerFactory.getLogger(MemberImportServiceImpl.class);
    @Override
    public void importMember(File excelFile) {
        try {
            InputStream resource = new ClassPathResource("data/member-data.xlsx").getInputStream();
            Workbook workbook = new XSSFWorkbook(resource);

            Sheet sheet = workbook.getSheetAt(0);
            logger.info("last rowNum: {}",sheet.getLastRowNum());

            //validate header fund, company as of date
            //...


            //validate member data and update to database
            //loop validate and update 500 member/loop
            int batchSize = 500;
            int loopNum = (sheet.getLastRowNum()/batchSize)+1;
            for(int i=0; i<= loopNum; i++) {

                int from = 1 + (batchSize * n);
                int to = 500 + (batchSize * n);
                Map<Integer, List<String>> data = data(sheet, from, to);
                logger.info("data: {}", data);

                //mapping data to model
                Map<Integer, MemberRiskModel> memberRiskModelMap = mapToModel(data);

                //Validate
                //existsMembers = select employee code,as-of-date by fund, company, employee code from database
                //map existsMembers to Map<Employee Code, Model> เพื่อใช้ตอน validate ให้ get ด้วย employee code ไป validate ได้
                Map<String, MemberRiskEntity> existsMemberRiskMap = ...;
                for (MemberRiskModel memberRiskModel : memberRiskModelMap) {
                    memberRiskModel = validateModel(memberRiskModel, existsMemberRiskMap);
                    memberRiskModelMap.put(memberRiskModel.getRowNum(), memberRiskDataMap);
                }

                //update valid rows to database
                //--> delete by fund, company, member_uid only valid data
                //--> insert with database batch processing

                //update error rows to error model

            };


            //insert summary and error to database



        } catch (IOException e) {
            throw new RuntimeException(e);
        }


    }

    private MemberRiskModel validateModel(MemberRiskModel memberRiskModel, Map<String, MemberRiskEntity> existsMemberRiskMap) {
        // validate and set error to model

        //--> validate risk level with possible value 1-5

        //--> validate fx rate is 'Y' or 'N'

        //--> validate as-of-date

        //--> validate employee code

        return memberRiskModel;
    }



    private Map<Integer, MemberRiskModel> mapToModel(Map<Integer, List<String>> data) {
        Map<Integer, MemberRiskModel> memberRiskDataMap = new HashMap<>();
        //implement logic to map value to model

        return memberRiskDataMap;
    }


    private Map<Integer, List<String>> data(Sheet sheet, int from, int to) {
        Map<Integer, List<String>> data = new HashMap<>();

        for (int i=from;i<=to;i++) {
            Row row = sheet.getRow(i);
            data.put(i, new ArrayList<String>());
            for (Cell cell : row) {
                switch (cell.getCellType()) {
                    case STRING:
                        data.get(i).add(cell.getRichStringCellValue().getString());
                        break;
                    case NUMERIC:
                        if (DateUtil.isCellDateFormatted(cell)) {
                            data.get(i).add(cell.getDateCellValue() + "");
                        } else {
                            data.get(i).add((int)cell.getNumericCellValue() + "");
                        }
                        break;
                    case BOOLEAN:
                        data.get(i).add(cell.getBooleanCellValue() + "");
                        break;
                    case FORMULA:
                        data.get(i).add(cell.getCellFormula() + "");
                        break;
                    default: data.get(i).add(" ");
                }
            }
        }

        return data;
    }
}
