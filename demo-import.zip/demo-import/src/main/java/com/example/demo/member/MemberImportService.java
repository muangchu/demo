package com.example.demo.member;

import java.io.File;

public interface MemberImportService {
    void importMember(File file);
}
