DROP TABLE members IF EXISTS;

CREATE TABLE members  (
    first_name VARCHAR(20),
    last_name VARCHAR(20)
);
