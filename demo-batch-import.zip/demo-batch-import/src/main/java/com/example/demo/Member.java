package com.example.demo;

public record Member(String firstName, String lastName) {

}
