package com.example.demo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;

public class MemberItemProcessor implements ItemProcessor<Member, Member> {
    private static final Logger logger = LoggerFactory.getLogger(MemberItemProcessor.class);

    @Override
    public Member process(final Member member) throws Exception {
        final Member transformedMember = new Member(member.firstName().toUpperCase(),member.lastName().toUpperCase());

        logger.info("Converting ({}) into ({})",member,transformedMember);

        return transformedMember;
    }
}
