package com.example.demo;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;

@Configuration
//@EnableBatchProcessing
public class BatchConfig {

    @Bean
    public PlatformTransactionManager transactionManager(DataSource dataSource) {
        return new DataSourceTransactionManager(dataSource);
    }

    @Bean
    @StepScope
    public FlatFileItemReader<Member> reader(@Value("#{jobParameters[fullPathFileName]}") String pathToFile) {
        return new FlatFileItemReaderBuilder<Member>()
                .name("memberItemReader")
                //.resource(new ClassPathResource("sample-data.csv"))
                .resource(new FileSystemResource(pathToFile))
                .delimited()
                .names("firstName","lastName")
                .targetType(Member.class)
                .build();
    }

    @Bean
    public MemberItemProcessor processor() {
        return new MemberItemProcessor();
    }

    @Bean
    public JdbcBatchItemWriter<Member> writer(DataSource dataSource) {
        return new JdbcBatchItemWriterBuilder<Member>()
                .sql("INSERT INTO members (first_name, last_name) VALUES (:firstName, :lastName)")
                .dataSource(dataSource)
                .beanMapped()
                .build();
    }


    @Bean
    public Job importMemberJob(JobRepository jobRepository,Step step1, JobCompletionNotificationListener listener) {
        return new JobBuilder("importMemberJob", jobRepository)
                .listener(listener)
                .start(step1)
                .build();
    }


    @Bean
    public Step step1(JobRepository jobRepository,
                      DataSourceTransactionManager transactionManager,
                      FlatFileItemReader<Member> reader,
                      MemberItemProcessor processor,
                      JdbcBatchItemWriter<Member> writer) {
        return new StepBuilder("step1", jobRepository)
                .<Member, Member> chunk(3, transactionManager)
                .reader(reader)
                .processor(processor)
                .writer(writer)
                .build();
    }



}
