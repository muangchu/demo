package com.example.demo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;

@RestController
@RequestMapping("/api")
public class FileUploadController {

    private static final Logger logger = LoggerFactory.getLogger(FileUploadController.class);

    @Autowired
    private JobLauncher jobLauncher;

    @Autowired
    private Job importMemberJob;

    @PostMapping("/upload")
    public ResponseEntity<String> handleFileUpload(@RequestParam("file") MultipartFile file) {
        File tempFile = null;
        try{
            // Save the file to a temporary location
            tempFile = File.createTempFile("upload-", ".csv");
            Files.write(tempFile.toPath(), file.getBytes());

            // Launch the batch job
            JobParameters jobParameters = new JobParametersBuilder()
                    .addString("fullPathFileName", tempFile.toString())
                    .addLong("time", System.currentTimeMillis())
                    .toJobParameters();

            jobLauncher.run(importMemberJob, jobParameters);

            return ResponseEntity.ok("File uploaded successfully and job started.");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to upload file and start job.");
        } finally {
            if(tempFile != null && tempFile.exists()){
                logger.info("Delete temp file '{}'",tempFile.getName());
                tempFile.delete();
            }
        }
    }
}
